﻿
namespace GameDevPOE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            crntPlayerPic = new PictureBox();
            oppPlayerPic = new PictureBox();
            lblCrntPlayerName = new Label();
            lblOppDragonName = new Label();
            Attack = new Button();
            SpAttack = new Button();
            Block = new Button();
            battleLog = new TextBox();
            lblCrntDragonName = new Label();
            oppDragonHp = new Label();
            lblOppPlayerName = new Label();
            lblCrntHP = new Label();
            lblStats = new Label();
            Rest = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)crntPlayerPic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)oppPlayerPic).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.PlayerTurnBack2;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(0, -2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1119, 688);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // crntPlayerPic
            // 
            crntPlayerPic.BackgroundImage = Properties.Resources.FireDragon;
            crntPlayerPic.BackgroundImageLayout = ImageLayout.Stretch;
            crntPlayerPic.Location = new Point(62, 79);
            crntPlayerPic.Name = "crntPlayerPic";
            crntPlayerPic.Size = new Size(300, 300);
            crntPlayerPic.TabIndex = 1;
            crntPlayerPic.TabStop = false;
            // 
            // oppPlayerPic
            // 
            oppPlayerPic.BackgroundImage = Properties.Resources.IceDragon;
            oppPlayerPic.BackgroundImageLayout = ImageLayout.Stretch;
            oppPlayerPic.Location = new Point(678, 70);
            oppPlayerPic.Name = "oppPlayerPic";
            oppPlayerPic.Size = new Size(200, 200);
            oppPlayerPic.TabIndex = 2;
            oppPlayerPic.TabStop = false;
            // 
            // lblCrntPlayerName
            // 
            lblCrntPlayerName.AutoSize = true;
            lblCrntPlayerName.BackColor = Color.FromArgb(0, 64, 64);
            lblCrntPlayerName.Font = new Font("Segoe UI", 20F);
            lblCrntPlayerName.ForeColor = SystemColors.Control;
            lblCrntPlayerName.Location = new Point(62, 30);
            lblCrntPlayerName.Name = "lblCrntPlayerName";
            lblCrntPlayerName.Size = new Size(235, 46);
            lblCrntPlayerName.TabIndex = 3;
            lblCrntPlayerName.Text = "Player 1 Name";
            // 
            // lblOppDragonName
            // 
            lblOppDragonName.AutoSize = true;
            lblOppDragonName.BackColor = Color.FromArgb(192, 0, 0);
            lblOppDragonName.Font = new Font("Segoe UI", 15F);
            lblOppDragonName.ForeColor = SystemColors.Control;
            lblOppDragonName.Location = new Point(908, 70);
            lblOppDragonName.Name = "lblOppDragonName";
            lblOppDragonName.Size = new Size(185, 70);
            lblOppDragonName.TabIndex = 4;
            lblOppDragonName.Text = "Tundra, \r\nThe Ice Dragon";
            // 
            // Attack
            // 
            Attack.BackColor = Color.FromArgb(0, 192, 192);
            Attack.Font = new Font("Segoe UI", 15F);
            Attack.ForeColor = SystemColors.Control;
            Attack.Location = new Point(62, 400);
            Attack.Name = "Attack";
            Attack.Size = new Size(300, 45);
            Attack.TabIndex = 5;
            Attack.Text = "Attack";
            Attack.UseVisualStyleBackColor = false;
            Attack.Click += Attack_Click;
            // 
            // SpAttack
            // 
            SpAttack.BackColor = Color.Teal;
            SpAttack.Font = new Font("Segoe UI", 15F);
            SpAttack.ForeColor = SystemColors.Control;
            SpAttack.Location = new Point(62, 478);
            SpAttack.Name = "SpAttack";
            SpAttack.Size = new Size(300, 45);
            SpAttack.TabIndex = 6;
            SpAttack.Text = "Special Attack";
            SpAttack.UseVisualStyleBackColor = false;
            SpAttack.Click += SpAttack_Click;
            // 
            // Block
            // 
            Block.BackColor = Color.FromArgb(0, 64, 64);
            Block.Font = new Font("Segoe UI", 15F);
            Block.ForeColor = SystemColors.Control;
            Block.Location = new Point(62, 558);
            Block.Name = "Block";
            Block.Size = new Size(300, 45);
            Block.TabIndex = 7;
            Block.Text = "Block";
            Block.UseVisualStyleBackColor = false;
            Block.Click += Block_Click;
            // 
            // battleLog
            // 
            battleLog.BackColor = Color.Maroon;
            battleLog.BorderStyle = BorderStyle.None;
            battleLog.ForeColor = Color.White;
            battleLog.Location = new Point(501, 400);
            battleLog.Multiline = true;
            battleLog.Name = "battleLog";
            battleLog.ReadOnly = true;
            battleLog.ScrollBars = ScrollBars.Vertical;
            battleLog.Size = new Size(606, 206);
            battleLog.TabIndex = 8;
            battleLog.Text = "Lupe's Turn:\r\nTundra attacks Boulder and deals 4 DP, Boulder has 36 HP left\r\n****************************************************************************";
            // 
            // lblCrntDragonName
            // 
            lblCrntDragonName.AutoSize = true;
            lblCrntDragonName.BackColor = Color.FromArgb(0, 64, 64);
            lblCrntDragonName.Font = new Font("Segoe UI", 15F);
            lblCrntDragonName.ForeColor = SystemColors.Control;
            lblCrntDragonName.Location = new Point(402, 79);
            lblCrntDragonName.Name = "lblCrntDragonName";
            lblCrntDragonName.Size = new Size(193, 70);
            lblCrntDragonName.TabIndex = 9;
            lblCrntDragonName.Text = "Ash,\r\nThe Fire Dragon";
            lblCrntDragonName.Click += lblCrntDragonName_Click;
            // 
            // oppDragonHp
            // 
            oppDragonHp.AutoSize = true;
            oppDragonHp.BackColor = Color.FromArgb(192, 0, 0);
            oppDragonHp.Font = new Font("Segoe UI", 20F);
            oppDragonHp.ForeColor = SystemColors.Control;
            oppDragonHp.Location = new Point(908, 153);
            oppDragonHp.Name = "oppDragonHp";
            oppDragonHp.Size = new Size(115, 46);
            oppDragonHp.TabIndex = 10;
            oppDragonHp.Text = "HP: 30";
            oppDragonHp.Click += label4_Click;
            // 
            // lblOppPlayerName
            // 
            lblOppPlayerName.AutoSize = true;
            lblOppPlayerName.BackColor = Color.FromArgb(192, 0, 0);
            lblOppPlayerName.Font = new Font("Segoe UI", 15F);
            lblOppPlayerName.ForeColor = SystemColors.Control;
            lblOppPlayerName.Location = new Point(678, 32);
            lblOppPlayerName.Name = "lblOppPlayerName";
            lblOppPlayerName.Size = new Size(176, 35);
            lblOppPlayerName.TabIndex = 11;
            lblOppPlayerName.Text = "Player 2 Name";
            // 
            // lblCrntHP
            // 
            lblCrntHP.AutoSize = true;
            lblCrntHP.BackColor = Color.FromArgb(0, 64, 64);
            lblCrntHP.Font = new Font("Segoe UI", 20F);
            lblCrntHP.ForeColor = SystemColors.Control;
            lblCrntHP.Location = new Point(402, 153);
            lblCrntHP.Name = "lblCrntHP";
            lblCrntHP.Size = new Size(115, 46);
            lblCrntHP.TabIndex = 12;
            lblCrntHP.Text = "HP: 25";
            lblCrntHP.Click += label1_Click;
            // 
            // lblStats
            // 
            lblStats.AutoSize = true;
            lblStats.BackColor = Color.FromArgb(0, 64, 64);
            lblStats.Font = new Font("Segoe UI", 15F);
            lblStats.ForeColor = SystemColors.Control;
            lblStats.Location = new Point(402, 218);
            lblStats.Name = "lblStats";
            lblStats.Size = new Size(181, 105);
            lblStats.TabIndex = 13;
            lblStats.Text = "Attack: \r\nSpecial Attack: \r\nBlock: ";
            // 
            // Rest
            // 
            Rest.BackColor = Color.FromArgb(192, 0, 0);
            Rest.Font = new Font("Segoe UI", 15F);
            Rest.ForeColor = SystemColors.Control;
            Rest.Location = new Point(62, 628);
            Rest.Name = "Rest";
            Rest.Size = new Size(300, 45);
            Rest.TabIndex = 14;
            Rest.Text = "Rest";
            Rest.UseVisualStyleBackColor = false;
            Rest.Visible = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1119, 686);
            Controls.Add(Rest);
            Controls.Add(lblStats);
            Controls.Add(lblCrntHP);
            Controls.Add(lblOppPlayerName);
            Controls.Add(oppDragonHp);
            Controls.Add(lblCrntDragonName);
            Controls.Add(battleLog);
            Controls.Add(Block);
            Controls.Add(SpAttack);
            Controls.Add(Attack);
            Controls.Add(lblOppDragonName);
            Controls.Add(lblCrntPlayerName);
            Controls.Add(oppPlayerPic);
            Controls.Add(crntPlayerPic);
            Controls.Add(pictureBox1);
            Name = "Form2";
            Text = "Dragon Duels";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)crntPlayerPic).EndInit();
            ((System.ComponentModel.ISupportInitialize)oppPlayerPic).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void lblCrntDragonName_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox crntPlayerPic;
        private PictureBox oppPlayerPic;
        private Label lblCrntPlayerName;
        private Label lblOppDragonName;
        private Button Attack;
        private Button SpAttack;
        private Button Block;
        private TextBox battleLog;
        private Label lblCrntDragonName;
        private Label oppDragonHp;
        private Label lblOppPlayerName;
        private Label lblCrntHP;
        private Label lblStats;
        private Button Rest;
    }
}