namespace GameDevPOE
{
    public partial class Form1 : Form
    {

        // Step 1: Declare Arrays and Constants
        // Arrays to store player data
        string[] P1data = new string[4];
        string[] P2data = new string[4];
        int[] P1values = new int[4];
        int[] P2values = new int[4];

        // Constants for dragon stats and types
        const string FIRE_DRAG_NAME = "Fire Dragon";
        const int FIRE_DRAG_HP = 20;
        const int FIRE_DRAG_ATK = 5;
        const int FIRE_DRAG_SPATK = 12;
        const int FIRE_DRAG_BLOCK = 4;

        const string ICE_DRAG_NAME = "Ice Dragon";
        const int ICE_DRAG_HP = 30;
        const int ICE_DRAG_ATK = 4;
        const int ICE_DRAG_SPATK = 9;
        const int ICE_DRAG_BLOCK = 5;

        const string WIND_DRAG_NAME = "Wind Dragon";
        const int WIND_DRAG_HP = 40;
        const int WIND_DRAG_ATK = 3;
        const int WIND_DRAG_SPATK = 7;
        const int WIND_DRAG_BLOCK = 5;

        const string EARTH_DRAG_NAME = "Earth Dragon";
        const int EARTH_DRAG_HP = 50;
        const int EARTH_DRAG_ATK = 2;
        const int EARTH_DRAG_SPATK = 5;
        const int EARTH_DRAG_BLOCK = 6;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.StartUpBackGround;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            pictureBox2.Image = Properties.Resources.FireDragon;
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.Image = Properties.Resources.IceDragon;
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.Image = Properties.Resources.EarthDragon;
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.Image = Properties.Resources.WindDragon;
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.Image = Properties.Resources.IceDragon;
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.Image = Properties.Resources.FireDragon;
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.Image = Properties.Resources.EarthDragon;
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.Image = Properties.Resources.WindDragon;
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;

            button1.Enabled = false;

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        // Method to return selected dragon type from the Radio Buttons
        private string SelectDragonType(string player)
        {
            string Type = "";

            if (player == "Player 1")
            {
                if (radioButton1.Checked)
                {
                    Type = FIRE_DRAG_NAME;
                }
                else if (radioButton2.Checked)
                {
                    Type = ICE_DRAG_NAME;
                }
                else if (radioButton3.Checked)
                {
                    Type = EARTH_DRAG_NAME;
                }
                else if (radioButton4.Checked)
                {
                    Type = WIND_DRAG_NAME;
                }
            }

            else
            {
                if (radioButton8.Checked)
                {
                    Type = FIRE_DRAG_NAME;
                }
                else if (radioButton7.Checked)
                {
                    Type = ICE_DRAG_NAME;
                }
                else if (radioButton6.Checked)
                {
                    Type = EARTH_DRAG_NAME;
                }
                else if (radioButton5.Checked)
                {
                    Type = WIND_DRAG_NAME;
                }
            }

            return Type;

        }

        // Step 2: Implement saveValues() Method
        // Method to save player data based on selected dragon type
        private void SaveValues(string player, string playerName, string dragonName, string dragonType)
        {

            if (player == "1")
            {
                P1data[0] = playerName;
                P1data[1] = dragonName;
                P1data[2] = dragonType;
                P1data[3] = player;

                switch (dragonType)
                {
                    case FIRE_DRAG_NAME:
                        P1values[0] = FIRE_DRAG_HP;
                        P1values[1] = FIRE_DRAG_ATK;
                        P1values[2] = FIRE_DRAG_SPATK;
                        P1values[3] = FIRE_DRAG_BLOCK;
                        break;
                    case ICE_DRAG_NAME:
                        P1values[0] = ICE_DRAG_HP;
                        P1values[1] = ICE_DRAG_ATK;
                        P1values[2] = ICE_DRAG_SPATK;
                        P1values[3] = ICE_DRAG_BLOCK;
                        break;
                    case WIND_DRAG_NAME:
                        P1values[0] = WIND_DRAG_HP;
                        P1values[1] = WIND_DRAG_ATK;
                        P1values[2] = WIND_DRAG_SPATK;
                        P1values[3] = WIND_DRAG_BLOCK;
                        break;
                    case EARTH_DRAG_NAME:
                        P1values[0] = EARTH_DRAG_HP;
                        P1values[1] = EARTH_DRAG_ATK;
                        P1values[2] = EARTH_DRAG_SPATK;
                        P1values[3] = EARTH_DRAG_BLOCK;
                        break;
                    default:
                        break;
                }
                button3.Enabled = false;
            }

            else
            {
                P2data[0] = playerName;
                P2data[1] = dragonName;
                P2data[2] = dragonType;
                P2data[3] = player;

                switch (dragonType)
                {
                    case FIRE_DRAG_NAME:
                        P2values[0] = FIRE_DRAG_HP;
                        P2values[1] = FIRE_DRAG_ATK;
                        P2values[2] = FIRE_DRAG_SPATK;
                        P2values[3] = FIRE_DRAG_BLOCK;
                        break;
                    case ICE_DRAG_NAME:
                        P2values[0] = ICE_DRAG_HP;
                        P2values[1] = ICE_DRAG_ATK;
                        P2values[2] = ICE_DRAG_SPATK;
                        P2values[3] = ICE_DRAG_BLOCK;
                        break;
                    case WIND_DRAG_NAME:
                        P2values[0] = WIND_DRAG_HP;
                        P2values[1] = WIND_DRAG_ATK;
                        P2values[2] = WIND_DRAG_SPATK;
                        P2values[3] = WIND_DRAG_BLOCK;
                        break;
                    case EARTH_DRAG_NAME:
                        P2values[0] = EARTH_DRAG_HP;
                        P2values[1] = EARTH_DRAG_ATK;
                        P2values[2] = EARTH_DRAG_SPATK;
                        P2values[3] = EARTH_DRAG_BLOCK;
                        break;
                    default:
                        break;
                }
                button2.Enabled = false;
            }
            // Enable start button if both players have saved their data
            if (!button2.Enabled && !button3.Enabled)
                button1.Enabled = true;
        }

        // Step 3: Call SaveValues() Method on Save Button
        // Event handler for Player 1 save button
        private void button3_Click(object sender, EventArgs e)
        {
            string playerName;
            string player = "1";
            string dragonName;
            string dragonType;

            playerName = textBox1.Text;
            dragonName = textBox2.Text;
            dragonType = SelectDragonType("Player 1");

            groupBox5.Show();

            switch (dragonType)
            {
                case FIRE_DRAG_NAME:
                    pictureBox10.Image = Properties.Resources.FireDragon;
                    pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case ICE_DRAG_NAME:
                    pictureBox10.Image = Properties.Resources.IceDragon;
                    pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case EARTH_DRAG_NAME:
                    pictureBox10.Image = Properties.Resources.EarthDragon;
                    pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case WIND_DRAG_NAME:
                    pictureBox10.Image = Properties.Resources.WindDragon;
                    pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
            }

            label5.Text = playerName;
            SaveValues(player, playerName,dragonName,dragonType);

        }

        // Event handler for Player 2 save button
        private void button2_Click(object sender, EventArgs e)
        {

            string playerName;
            string player = "2";
            string dragonName;
            string dragonType;

            playerName = textBox4.Text;
            dragonName = textBox3.Text;
            dragonType = SelectDragonType("Player 2");

            groupBox6.Show();

            switch (dragonType)
            {
                case FIRE_DRAG_NAME:
                    pictureBox11.Image = Properties.Resources.FireDragon;
                    pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case ICE_DRAG_NAME:
                    pictureBox11.Image = Properties.Resources.IceDragon;
                    pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case EARTH_DRAG_NAME:
                    pictureBox11.Image = Properties.Resources.EarthDragon;
                    pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case WIND_DRAG_NAME:
                    pictureBox11.Image = Properties.Resources.WindDragon;
                    pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
            }

            label6.Text = playerName;
            SaveValues(player, playerName, dragonName, dragonType);

        }

        // Step 4: Handle Start Game Button
        // Event handler for start button
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 PlayInterface = new Form2(P1data, P1values,P2data, P2values);
            PlayInterface.Show();
            this.Hide();
        }
    }
}
