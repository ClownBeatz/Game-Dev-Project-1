﻿namespace GameDevPOE
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            groupBox3 = new GroupBox();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            button3 = new Button();
            groupBox2 = new GroupBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            groupBox4 = new GroupBox();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            button2 = new Button();
            groupBox5 = new GroupBox();
            label5 = new Label();
            pictureBox10 = new PictureBox();
            groupBox6 = new GroupBox();
            label6 = new Label();
            pictureBox11 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox2.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(480, 570);
            button1.Name = "button1";
            button1.Size = new Size(160, 55);
            button1.TabIndex = 3;
            button1.Text = "Start";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.StartUpBackGround;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1119, 688);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Teal;
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(button3);
            groupBox1.ForeColor = SystemColors.Control;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(433, 662);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Player 1";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.Teal;
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.ForeColor = SystemColors.Control;
            textBox2.Location = new Point(95, 98);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(316, 27);
            textBox2.TabIndex = 11;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Teal;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.ForeColor = SystemColors.Control;
            textBox1.Location = new Point(95, 44);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(316, 27);
            textBox1.TabIndex = 10;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Teal;
            groupBox3.Controls.Add(radioButton4);
            groupBox3.Controls.Add(radioButton3);
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(radioButton1);
            groupBox3.Controls.Add(pictureBox5);
            groupBox3.Controls.Add(pictureBox4);
            groupBox3.Controls.Add(pictureBox3);
            groupBox3.Controls.Add(pictureBox2);
            groupBox3.ForeColor = SystemColors.Control;
            groupBox3.Location = new Point(20, 147);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(391, 466);
            groupBox3.TabIndex = 9;
            groupBox3.TabStop = false;
            groupBox3.Text = "Dragon Type";
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(6, 370);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(197, 84);
            radioButton4.TabIndex = 5;
            radioButton4.TabStop = true;
            radioButton4.Text = "Wind Dragon: 40 HP\r\n3 Attack Damage\r\n7 Special Attack Damage\r\n5 Block Damage";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(6, 260);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(197, 84);
            radioButton3.TabIndex = 17;
            radioButton3.TabStop = true;
            radioButton3.Text = "Earth Dragon: 50 HP\r\n2 Attack Damage\r\n5 Special Attack Damage\r\n6 Block Damage";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(6, 152);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(197, 84);
            radioButton2.TabIndex = 16;
            radioButton2.TabStop = true;
            radioButton2.Text = "Ice Dragon: 30 HP\r\n4 Attack Damage\r\n9 Special Attack Damage\r\n5 Block Damage\r\n";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(6, 49);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(205, 84);
            radioButton1.TabIndex = 5;
            radioButton1.TabStop = true;
            radioButton1.Text = "Fire Dragon: 20 HP\r\n5 Attack Damage\r\n12 Special Attack Damage\r\n4 Block Damage";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImage = Properties.Resources.IceDragon;
            pictureBox5.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox5.Location = new Point(289, 151);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(85, 85);
            pictureBox5.TabIndex = 3;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = Properties.Resources.EarthDragon;
            pictureBox4.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox4.Location = new Point(289, 259);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(85, 85);
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = Properties.Resources.WindDragon;
            pictureBox3.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox3.Location = new Point(289, 370);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(85, 85);
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources.FireDragon;
            pictureBox2.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox2.Location = new Point(289, 49);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(85, 85);
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 101);
            label2.Name = "label2";
            label2.Size = new Size(62, 20);
            label2.TabIndex = 8;
            label2.Text = "Dragon:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 44);
            label1.Name = "label1";
            label1.Size = new Size(52, 20);
            label1.TabIndex = 7;
            label1.Text = "Name:";
            // 
            // button3
            // 
            button3.ForeColor = SystemColors.ActiveCaptionText;
            button3.Location = new Point(154, 619);
            button3.Name = "button3";
            button3.Size = new Size(127, 37);
            button3.TabIndex = 6;
            button3.Text = "Save";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Teal;
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(textBox4);
            groupBox2.Controls.Add(groupBox4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(button2);
            groupBox2.ForeColor = SystemColors.Control;
            groupBox2.Location = new Point(674, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(433, 662);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Player 2";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.Teal;
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.ForeColor = SystemColors.Control;
            textBox3.Location = new Point(95, 98);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(316, 27);
            textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.Teal;
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.ForeColor = SystemColors.Control;
            textBox4.Location = new Point(95, 44);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(316, 27);
            textBox4.TabIndex = 10;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.Teal;
            groupBox4.Controls.Add(radioButton5);
            groupBox4.Controls.Add(radioButton6);
            groupBox4.Controls.Add(radioButton7);
            groupBox4.Controls.Add(radioButton8);
            groupBox4.Controls.Add(pictureBox6);
            groupBox4.Controls.Add(pictureBox7);
            groupBox4.Controls.Add(pictureBox8);
            groupBox4.Controls.Add(pictureBox9);
            groupBox4.ForeColor = SystemColors.Control;
            groupBox4.Location = new Point(20, 147);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(391, 466);
            groupBox4.TabIndex = 9;
            groupBox4.TabStop = false;
            groupBox4.Text = "Dragon Type";
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Location = new Point(6, 370);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(197, 84);
            radioButton5.TabIndex = 5;
            radioButton5.TabStop = true;
            radioButton5.Text = "Wind Dragon: 40 HP\r\n3 Attack Damage\r\n7 Special Attack Damage\r\n5 Block Damage";
            radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Location = new Point(6, 260);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(197, 84);
            radioButton6.TabIndex = 17;
            radioButton6.TabStop = true;
            radioButton6.Text = "Earth Dragon: 50 HP\r\n2 Attack Damage\r\n5 Special Attack Damage\r\n6 Block Damage";
            radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Location = new Point(6, 152);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(197, 84);
            radioButton7.TabIndex = 16;
            radioButton7.TabStop = true;
            radioButton7.Text = "Ice Dragon: 30 HP\r\n4 Attack Damage\r\n9 Special Attack Damage\r\n5 Block Damage\r\n";
            radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Location = new Point(6, 49);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(205, 84);
            radioButton8.TabIndex = 5;
            radioButton8.TabStop = true;
            radioButton8.Text = "Fire Dragon: 20 HP\r\n5 Attack Damage\r\n12 Special Attack Damage\r\n4 Block Damage";
            radioButton8.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImage = Properties.Resources.IceDragon;
            pictureBox6.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox6.Location = new Point(289, 151);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(85, 85);
            pictureBox6.TabIndex = 3;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackgroundImage = Properties.Resources.EarthDragon;
            pictureBox7.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox7.Location = new Point(289, 259);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(85, 85);
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackgroundImage = Properties.Resources.WindDragon;
            pictureBox8.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox8.Location = new Point(289, 370);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(85, 85);
            pictureBox8.TabIndex = 1;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.BackgroundImage = Properties.Resources.FireDragon;
            pictureBox9.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox9.Location = new Point(289, 49);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(85, 85);
            pictureBox9.TabIndex = 0;
            pictureBox9.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 101);
            label3.Name = "label3";
            label3.Size = new Size(62, 20);
            label3.TabIndex = 8;
            label3.Text = "Dragon:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(20, 44);
            label4.Name = "label4";
            label4.Size = new Size(52, 20);
            label4.TabIndex = 7;
            label4.Text = "Name:";
            // 
            // button2
            // 
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(154, 619);
            button2.Name = "button2";
            button2.Size = new Size(127, 37);
            button2.TabIndex = 6;
            button2.Text = "Save";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // groupBox5
            // 
            groupBox5.BackColor = Color.FromArgb(0, 192, 192);
            groupBox5.Controls.Add(label5);
            groupBox5.Controls.Add(pictureBox10);
            groupBox5.Location = new Point(451, 12);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(217, 231);
            groupBox5.TabIndex = 13;
            groupBox5.TabStop = false;
            groupBox5.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 15F);
            label5.ForeColor = SystemColors.Control;
            label5.Location = new Point(67, 180);
            label5.Name = "label5";
            label5.Size = new Size(81, 35);
            label5.TabIndex = 19;
            label5.Text = "label5";
            // 
            // pictureBox10
            // 
            pictureBox10.BackgroundImage = Properties.Resources.FireDragon;
            pictureBox10.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox10.Location = new Point(48, 44);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(117, 117);
            pictureBox10.TabIndex = 18;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // groupBox6
            // 
            groupBox6.BackColor = Color.Red;
            groupBox6.Controls.Add(label6);
            groupBox6.Controls.Add(pictureBox11);
            groupBox6.Location = new Point(451, 272);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(217, 231);
            groupBox6.TabIndex = 20;
            groupBox6.TabStop = false;
            groupBox6.Visible = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15F);
            label6.ForeColor = SystemColors.Control;
            label6.Location = new Point(67, 178);
            label6.Name = "label6";
            label6.Size = new Size(81, 35);
            label6.TabIndex = 20;
            label6.Text = "label6";
            // 
            // pictureBox11
            // 
            pictureBox11.BackgroundImage = Properties.Resources.FireDragon;
            pictureBox11.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox11.Location = new Point(48, 39);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(117, 117);
            pictureBox11.TabIndex = 18;
            pictureBox11.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1119, 686);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "Dragon Duels";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button button1;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private TextBox textBox2;
        private TextBox textBox1;
        private GroupBox groupBox3;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private Button button3;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private GroupBox groupBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private GroupBox groupBox4;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private Label label3;
        private Label label4;
        private Button button2;
        private GroupBox groupBox5;
        private PictureBox pictureBox10;
        private GroupBox groupBox6;
        private PictureBox pictureBox11;
        private Label label5;
        private Label label6;
    }
}
